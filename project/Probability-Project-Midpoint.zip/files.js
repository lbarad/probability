
//TO-DO
module.exports.setupFiles = () => {
    return true;
}

module.exports.getSampleFiles = () => {
    return [];
}